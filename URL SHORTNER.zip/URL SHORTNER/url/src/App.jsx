import React from 'react';
import UrlForm from './Components/UrlForm';

function App() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'Arial' }}>
      <h1> URL Shortener</h1>
      <UrlForm />
    </div>
  );
}

export default App;


