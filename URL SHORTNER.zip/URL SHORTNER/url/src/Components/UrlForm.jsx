import { useState } from 'react';
import axios from 'axios';

function UrlForm() {
  const [originalUrl, setOriginalUrl] = useState('');
  const [shortcode, setShortcode] = useState('');
  const [expiryMinutes, setExpiryMinutes] = useState(30);
  const [shortUrl, setShortUrl] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setShortUrl('');

    try {
      const res = await axios.post('/api/shorten', {
        originalUrl,
        customShortcode: shortcode || undefined,
        expiryMinutes: expiryMinutes || 30,
      });
      setShortUrl(res.data.shortUrl);
    } catch (err) {
      setError(err.response?.data?.error || 'Something went wrong.');
    }
  };

  return (
    <form onSubmit={handleSubmit} style={{ maxWidth: '500px' }}>
      <div>
        <label>Original URL:</label>
        <input
          type="url"
          required
          value={originalUrl}
          onChange={(e) => setOriginalUrl(e.target.value)}
          placeholder="Enter the link...."
          style={{ width: '100%', margin: '8px 0' }}
        />
      </div>
      <div>
        <label>Custom Shortcode:</label>
        <input
          value={shortcode}
          onChange={(e) => setShortcode(e.target.value)}
          placeholder="Enter your custom short code here..."
          style={{ width: '100%', margin: '8px 0' }}
        />
      </div>
      <div>
        <label>Expiry Time:</label>
        <input
          type="number"
          min="1"
          value={expiryMinutes}
          onChange={(e) => setExpiryMinutes(e.target.value)}
          style={{ width: '100%', margin: '8px 0' }}
        />
      </div>
      <button type="submit" style={{ marginTop: '10px' ,background:"red" }}>Shorten URL</button>

      {shortUrl && (
        <div style={{ marginTop: '20px' }}>
          Shortened URL: <a href={shortUrl} target="_blank" rel="noreferrer">{shortUrl}</a>
        </div>
      )}

      {error && (
        <div style={{ color: 'red', marginTop: '10px' }}>
          {error}
        </div>
      )}
    </form>
  );
}

export default UrlForm;
